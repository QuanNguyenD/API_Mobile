<?php

namespace React\Dns;

class RecordNotFoundException extends \Exception
{
}
