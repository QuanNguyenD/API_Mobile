<?php

namespace React\Dns\Query;

class CancellationException extends \RuntimeException
{
}
