<?php

namespace React\Dns;

class BadServerException extends \Exception
{
}
