<?php

namespace React\Tests\EventLoop;

class CallableStub
{
    public function __invoke()
    {
    }
}
