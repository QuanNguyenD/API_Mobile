<?php

namespace React\Tests\Socket\Stub;

class CallableStub
{
    public function __invoke()
    {
    }
}
