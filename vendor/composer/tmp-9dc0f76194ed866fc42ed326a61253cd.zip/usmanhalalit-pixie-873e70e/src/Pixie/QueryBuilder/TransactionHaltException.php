<?php

namespace Pixie\QueryBuilder;

class TransactionHaltException extends \Exception
{
}
