<?php namespace Pixie\QueryBuilder\Adapters;

class Sqlite extends BaseAdapter
{
    /**
     * @var string
     */
    protected $sanitizer = '"';
}
