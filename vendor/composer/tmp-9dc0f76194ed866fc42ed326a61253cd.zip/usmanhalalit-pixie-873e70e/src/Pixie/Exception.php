<?php namespace Pixie;

class Exception extends \Exception
{

}
